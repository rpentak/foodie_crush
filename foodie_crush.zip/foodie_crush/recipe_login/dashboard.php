<?php
//include auth_session.php file on all user panel pages
include("auth_session.php");
include("header.php");
include("menu.php");
include("postr.php");
include("footer.php");
?>

